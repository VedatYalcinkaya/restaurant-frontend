import React from 'react'
import { TimelineDemo } from '../components/TimelineDemo'

const HomePage = () => {
  return (
    <>
    <TimelineDemo/>
    </>
  )
}

export default HomePage